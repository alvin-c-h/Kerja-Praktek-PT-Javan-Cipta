<!DOCTYPE html>
<html>
<head>
	<title>Kalkulator MVC Alvin Chandra</title>
</head>
<body>

	<form action="/hasil_kalkulator" method="GET">
		Angka 1 <input type="text" name="angka1" required="required"> <br>
            <br>
            <input type="radio" name="operator" value="+" checked> Tambah (+)<br>
            <input type="radio" name="operator" value="-"> Kurang (-)<br>
            <input type="radio" name="operator" value="x"> Kali (x)<br>
            <input type="radio" name="operator" value="/"> Bagi (/)<br>
            <br>
        Angka 2 <input type="text" name="angka2" required="required"> <br>
        <br>
		<input type="submit" value="Hitung">
	</form>

</body>
</html><?php /**PATH C:\Users\User\Documents\SEMESTER 6\KP\Magang Programmer PT Javan\Model_View_Controller_Menggunakan_Framework\kalkulator_MVC\resources\views/kalkulator_MVC.blade.php ENDPATH**/ ?>