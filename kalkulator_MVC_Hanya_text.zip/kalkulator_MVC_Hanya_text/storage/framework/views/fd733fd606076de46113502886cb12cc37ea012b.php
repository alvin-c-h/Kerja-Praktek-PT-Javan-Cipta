<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel - www.malasngoding.com</title>
</head>
<body>

	<form action="/hasil_kalkulator" method="GET">
		Input Hitungan <input type="text" name="inputHuruf" required="required"> <br/>
		<input type="submit" value="Hitung">
	</form>

</body>
</html><?php /**PATH C:\Users\User\Documents\SEMESTER 6\KP\Magang Programmer PT Javan\Model_View_Controller_Menggunakan_Framework\kalkulator_MVC\resources\views/kalkulator_MVC.blade.php ENDPATH**/ ?>