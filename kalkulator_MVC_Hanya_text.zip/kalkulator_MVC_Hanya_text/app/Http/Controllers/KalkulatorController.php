<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KalkulatorController extends Controller
{
    public function kalkulator_MVC()
    {

        // memanggil view kalkulator_MVC
        return view('kalkulator_MVC');

    }

    function kalkulatorSederhana(Request $request){
        echo 'kalkulator("'.$request->inputHuruf.'");//output : ';
    
        str_replace(" ","",$request->inputHuruf);
    
        $calculate=explode("+",$request->inputHuruf);
    
        if (count($calculate)>1){
            $hasil=(float)$calculate[0]+(float)$calculate[1];
            echo $hasil;
        }
        else{
            $min="-";
            for ($i = 1; $i < substr_count($request->inputHuruf,"-"); $i++) {
                $min.="-";  
            }
            $calculate=explode($min,$request->inputHuruf);
            if (count($calculate)>1){
                if (substr_count($request->inputHuruf,"-")%2==0){
                    $hasil=(float)$calculate[0]+(float)$calculate[1];
                    echo $hasil;
                }
                else{
                    $hasil=(float)$calculate[0]-(float)$calculate[1];
                    echo $hasil;
                }
            }
            else{
                $calculate=explode("x",$request->inputHuruf);
                if (count($calculate)>1){
                    $hasil=(float)$calculate[0]*(float)$calculate[1];
                    echo $hasil;
                }
                else{
                    $calculate=explode("/",$request->inputHuruf);
                    if (count($calculate)>1){
                        if ((float)$calculate[1]==0){
                            echo "tidak bisa dilakukan";
                        }
                        else{
                            $hasil=(float)$calculate[0]/(float)$calculate[1];
                            echo $hasil;
                        }
                    }
                }
            }
        }
    }
}