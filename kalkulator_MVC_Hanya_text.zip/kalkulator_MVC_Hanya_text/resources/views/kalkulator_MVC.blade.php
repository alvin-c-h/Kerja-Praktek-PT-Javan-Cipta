<!DOCTYPE html>
<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel - www.malasngoding.com</title>
</head>
<body>

	<form action="/hasil_kalkulator" method="GET">
		Input Hitungan <input type="text" name="inputHuruf" required="required"> <br/>
		<input type="submit" value="Hitung">
	</form>

</body>
</html>